# Unicode Character Database
# Date: 2021-08-26, 20:43:00 GMT
# © 2021 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use, see https://www.unicode.org/terms_of_use.html
#

This directory contains final data files for Unicode, Version 14.0

Public/14.0.0/emoji/

  emoji-data.txt
  emoji-variation-sequences.txt
  
The following related files are found in Unicode Emoji, Version 14.0

Public/emoji/14.0/

  emoji-sequences.txt
  emoji-zwj-sequences.txt
  emoji-test.txt

For documentation, see UTS #51 Unicode Emoji, Version 14.0
